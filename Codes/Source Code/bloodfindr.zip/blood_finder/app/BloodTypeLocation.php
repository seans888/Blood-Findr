<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BloodTypeLocation extends Model
{
    //
}
