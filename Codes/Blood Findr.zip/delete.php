<?php


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Origin, Content-Type");


$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);

$blood_id = $_POST["blood_id"];

$servername ="127.0.0.1";
$username = "root";
$password = "123123";
$dbName = "bloodfindr";

$conn = mysqli_connect($servername,$username,$password,$dbName);

if($conn->connect_error)
{
die("Connection failed". $conn->connect_error);
}


$sql = 'DELETE FROM blood WHERE blood_id="'. $blood_id .'"';


if($conn->query($sql) === TRUE)
{
 $outp = "Deleted " . $blood_id;
 echo json_encode($outp);
}else
{
echo json_encode("Error" . $conn->error);
}


$conn->close();

?>