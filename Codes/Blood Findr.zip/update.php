<?php


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Origin, Content-Type");


$rest_json = file_get_contents("php://input");
$_POST = json_decode($rest_json, true);

$blood_donorLoc = $_POST["blood_donorLoc"];
$blood_donateDate = $_POST["blood_donateDate"];

$servername ="127.0.0.1";
$username = "root";
$password = "123123";
$dbName = "prot1";

$conn = mysqli_connect($servername,$username,$password,$dbName);

if($conn->connect_error)
{
die("Connection failed". $conn->connect_error);
}


$sql = 'UPDATE blooda_pos SET blood_donorLoc="' . $blood_donorLoc . '" WHERE blood_donateDate="'. $blood_donateDate .'"';



if($conn->query($sql) === TRUE)
{
 $outp = "Updated " . $blood_donorLoc . " and " . $blood_donateDate;
 echo json_encode($outp);
}else
{
echo json_encode("Error" . $conn->error);
}


$conn->close();

?>