<?php

header("Access-Control-Allow-Origin: *");

$servername = "127.0.0.1";
$username = "root";
$password = "123123";
$dbName = "bloodfindr";

$conn = mysqli_connect($servername,$username,$password,$dbName);

if($conn-> connect_error)
{
	die("Connection failed" . $conn->connect_error);
}


$sql ="SELECT * from blood";


$result = mysqli_query($conn, $sql);


if(mysqli_num_rows($result)>0)
{
 $outp = array();
 $outp = $result->fetch_all(MYSQLI_ASSOC);
 echo json_encode($outp);
}else
{
echo json_encode("0 result");
}

$conn->close();

?>