<?php $__env->startSection('content'); ?>

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        
        <div class="logo-admin">
            <a href="<?php echo e(url('/admin')); ?>"><img src="<?php echo e(asset(config('app.asset').'images/logo.png' )); ?>"></a>
        </div>

        <?php if(Session::has('error')): ?>
            <div class="alert alert-warning text-center" role="alert">
                <?php echo e(Session::get('error')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?> 
            
            <div>
                <input type="text" name="email" class="textfield-admin" placeholder="Email">    
            </div>
            <div>
                <input type="password" name="password" class="textfield-admin" placeholder="Password">
            </div>
        
            <div class="text-center">
                <button type="submit" class="btn-admin">LOGIN</button>
                <span class="btn-admin-a">
                    <a href="<?php echo e(url('/register')); ?>">REGISTER</a>
                </span>
            </div>

        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/blood_finder/resources/views/auth/login.blade.php ENDPATH**/ ?>